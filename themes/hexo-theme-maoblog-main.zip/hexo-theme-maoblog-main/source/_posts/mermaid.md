---
title: mermaid test
date: 2023-08-15
tags:
  - Test
---

```mermaid
flowchart LR
    A-->B
    B-->C
```

